create function update_available_seats_on_reservation_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Decrease the available seats by the number of seats reserved in this reservation
    UPDATE flight
    SET available_seats = available_seats - NEW.seats_number
    WHERE flight_id = NEW.flight_id;

    RETURN NEW;
END;
$$;

alter function update_available_seats_on_reservation_insert() owner to imads;

