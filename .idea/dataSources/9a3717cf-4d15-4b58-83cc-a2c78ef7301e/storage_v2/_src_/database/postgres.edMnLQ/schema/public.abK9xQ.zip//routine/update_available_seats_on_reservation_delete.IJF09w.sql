create function update_available_seats_on_reservation_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Increase the available seats by the number of seats in the canceled reservation
    UPDATE flight
    SET available_seats = available_seats + OLD.seats_number
    WHERE flight_id = OLD.flight_id;

    RETURN OLD;
END;
$$;

alter function update_available_seats_on_reservation_delete() owner to imads;

